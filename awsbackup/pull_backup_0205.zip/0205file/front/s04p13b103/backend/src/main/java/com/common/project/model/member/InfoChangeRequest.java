package com.common.project.model.member;


import lombok.ToString;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.springframework.web.multipart.MultipartFile;
@Valid
@ToString
public class InfoChangeRequest {
    private Long uid;
    private String password;
    private String email;
    private String nickname;
    private String introduce;
    private MultipartFile profileImage;


    public MultipartFile getProfileImage() {
        return profileImage;
    }

    public void setProfileImage(MultipartFile profileImage) {
        this.profileImage = profileImage;
    }

    public Long getUid() {
        return uid;
    }

    public void setUid(Long uid) {
        this.uid = uid;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getIntroduce() {
        return introduce;
    }

    public void setIntroduce(String introduce) {
        this.introduce = introduce;
    }

	public InfoChangeRequest() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InfoChangeRequest(@NotNull String email,
            @NotNull @Pattern(regexp = "^(?=.*[A-Za-z])(?=.*\\d)[A-Za-z\\d$@$!%*#?&]{8,}$") String password, 
            @NotNull String nickname, String introduce) {
		super();
		this.email = email;
		this.password = password;
        this.nickname = nickname;
        this.introduce = introduce;
    }
    
    public InfoChangeRequest(Long uid, @NotNull String email,
            @NotNull @Pattern(regexp = "^(?=.*[A-Za-z])(?=.*\\d)[A-Za-z\\d$@$!%*#?&]{8,}$") String password, 
            @NotNull String nickname, String introduce) {
        super();
        this.uid = uid;
		this.email = email;
		this.password = password;
        this.nickname = nickname;
        this.introduce = introduce;
	}



}