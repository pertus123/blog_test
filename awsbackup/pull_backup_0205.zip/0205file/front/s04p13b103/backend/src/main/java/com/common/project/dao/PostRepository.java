package com.common.project.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.common.project.model.post.Post;

public interface PostRepository {
	Post findPostByPid(Long pid);
	Optional<Post> deletePostByPid(Long pid);
	
	@Query("SELECT p FROM Post p WHERE p.title like %:keyword% "
			+ "or p.content like %:keyword% ORDER BY p.pid desc")
    public List<Post> findPostByTitleOrContent(String keyword);
	
    
}