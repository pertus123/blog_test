package com.common.project.dao;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.Query;

import com.common.project.model.comment.Comment;

public interface CommentRepository {
	
	// 수정 필요
//	@Query(value = "select * from member where member.email = ?1 and member.password =?2", nativeQuery = true)
//	Optional<Comment> findMemberByEmailAndPassword(String email, String password);
	
	//@Query(value = "select * from comment where comment.pid = ?1 order by create_date", nativeQuery = true)
	//List<Comment> findByPidOrderByCreateDateAsc(Long pid);
	Optional<Comment> deleteBycid(Long cid);
	@Query(value = "select * from comment where comment.pid = ?1 order by create_date", nativeQuery = true)
	List<Comment> getByPidOrderByCreateDateAsc(Long pid);

}
