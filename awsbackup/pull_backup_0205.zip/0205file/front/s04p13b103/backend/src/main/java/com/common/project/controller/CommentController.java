package com.common.project.controller;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.common.project.dao.CommentDao;
import com.common.project.model.comment.Comment;
import com.common.project.model.comment.InputComment;
import com.common.project.model.comment.UpdateComment;
import com.common.project.model.member.Member;
import com.common.project.model.member.SignupInputMember;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@Transactional
@Api(tags = "CommentController", description = "댓글 API")
public class CommentController {
	//@Autowired
	
	@Autowired
	CommentDao commentDao;
	
	// 일단 완료
	@PostMapping("/cmt/write")
	@ApiOperation(value = "댓글쓰기")
	public Object writeComment(@RequestBody InputComment inputComment) {
		Comment comment = new Comment(inputComment.getPid(), inputComment.getEmail(), inputComment.getContent());
		
		commentDao.save(comment);
		System.out.println("111111111111111111111111111111111111");
		// 리스트
		List<Comment> commentList = commentDao.getByPidOrderByCreateDateAsc(inputComment.getPid());
		return new ResponseEntity<>(commentList, HttpStatus.OK);
		//return new ResponseEntity<>("good", HttpStatus.OK);
	}
	
	//일단 완료
	@GetMapping("/cmt/detail/{pid}")
	@ApiOperation(value = "댓글보기")
	public Object detailComment(@PathVariable Long pid) {
		List<Comment> commentList = commentDao.getByPidOrderByCreateDateAsc(pid);
		// 현재 pid 값을 가지고 모든 댓 글 가져요기 시간이 빠른 순으로 만약 비어 있으면 
		return new ResponseEntity<>(commentList, HttpStatus.OK);
	}
	
	// 일완
	@PutMapping("/cmt/update")
	@ApiOperation(value = "댓글수정")
	public Object updateComment(@RequestBody UpdateComment updateComment) {
		Comment comment = new Comment(updateComment.getCid(),updateComment.getPid(), updateComment.getEmail(), updateComment.getContent());
		commentDao.save(comment);
		List<Comment> commentList = commentDao.getByPidOrderByCreateDateAsc(updateComment.getPid());
		return new ResponseEntity<>(commentList, HttpStatus.OK);
	}
	
	//일단 완료
	@DeleteMapping("/cmt/delete/{cid}")
	@ApiOperation(value = "댓글삭제")
	public Object deleteComment(@PathVariable Long cid) {
		Optional<Comment> memberOpt = commentDao.deleteBycid(cid);
		if(memberOpt.isPresent())return new ResponseEntity<>("success",  HttpStatus.OK);
		else return new ResponseEntity<>("fail", HttpStatus.NOT_FOUND);
	}
}
