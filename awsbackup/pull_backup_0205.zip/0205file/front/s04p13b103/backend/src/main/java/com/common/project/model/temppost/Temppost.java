package com.common.project.model.temppost;

public class Temppost {

}
