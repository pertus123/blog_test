package com.common.project.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.common.project.dao.PostDao;
import com.common.project.dao.PostRepository;
//import com.common.project.model.member.InputMember;
import com.common.project.model.post.InputPost;
import com.common.project.model.post.Post;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@Transactional
@Api(tags = "PostController", description = "게시글 API")
public class PostController {
	@Autowired
	PostDao postDao;

	@GetMapping("/notice/searchAllPage")
	@ApiOperation(value = "검색이나 블로그 검색 할 때 글 리스트가져오기")
	public Object searchAllPage() {

		List<Post> postList = postDao.findAll();

		return new ResponseEntity<>(postList, HttpStatus.OK);
	}

	@GetMapping("/notice/searchByKeyword")
	@ApiOperation(value = "검색이나 블로그 검색 할 때 글 리스트가져오기")
	public Object searchPageByKeyword(@RequestParam(value = "keyword") String keyword) {

		List<Post> postList = postDao.findPostByTitleOrContent(keyword);
		
		return new ResponseEntity<>(postList, HttpStatus.OK);

	}

	@GetMapping("/notice/listUserPage/{uid}/X2")
	@ApiOperation(value = "사용자 페이지 리스트")
	public Object listUserPage(@PathVariable Long uid) {

		Optional<Post> listUserPage = postDao.findById(uid);

		return new ResponseEntity<>(listUserPage, HttpStatus.OK);
	}

	@GetMapping("/notice/detailPage/{pid}")
	@ApiOperation(value = "상세페이지")
	public Object detailPage(@PathVariable Long pid) {

		Post onePost = postDao.findPostByPid(pid);
		return new ResponseEntity<>(onePost, HttpStatus.OK);
	}

	@PostMapping("/notice/writePage")
	@ApiOperation(value = "글쓰기")
	public Object writePage(@RequestBody InputPost inputPost) {

		Post post = new Post(inputPost.getTitle(), inputPost.getEmail(), inputPost.getContent(), inputPost.getLikes());
		postDao.save(post);

		return new ResponseEntity<>("success", HttpStatus.OK);
	}

	@DeleteMapping("/notice/deletePage/{pid}")
	@ApiOperation(value = "글삭제")
	public Object deletePage(@PathVariable Long pid) {
		Optional<Post> postOpt = postDao.deletePostByPid(pid);
		// System.out.println(postOpt.toString());
		if (postOpt.isPresent()) {
			return new ResponseEntity<>("success", HttpStatus.OK);
		} else
			return new ResponseEntity<>("fail", HttpStatus.NOT_FOUND);

	}

	@PutMapping("/notice/updatePage")
	@ApiOperation(value = "글 수정")
	public Object updatePage(@RequestBody InputPost inputPost) {

		Post post = new Post(inputPost.getPid(), inputPost.getTitle(), inputPost.getEmail(), inputPost.getContent(),
				inputPost.getLikes());
		postDao.save(post);
		return new ResponseEntity<>("success", HttpStatus.OK);
	}

	@PostMapping("/notice/likePage/X")
	@ApiOperation(value = "좋아요&안좋아요")
	public Object likePage(@RequestBody InputPost inputPost) {
		return new ResponseEntity<>("success", HttpStatus.OK);
	}
	// @GetMapping("/notice/test/{inputURL}")
	// @ApiOperation(value = "크롤링 테스트")
	// public Object lectureList(@RequestBody String inputURL) {
	//
	// try {
	// Document doc = Jsoup.connect(inputURL).get();
	// Elements element = doc.select("div.sect-mo");
	//
	//
	// } catch (IOException e) {
	// e.printStackTrace();
	// }
	//
	//
	//
	//
	//
	//
	//
	// return new ResponseEntity<>("success", HttpStatus.OK);
	// }
}
