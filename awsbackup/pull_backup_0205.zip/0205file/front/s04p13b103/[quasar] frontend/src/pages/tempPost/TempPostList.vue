<template>
  <div>
    <div v-for="(loadedItem, index) in loadedItems"
      :key="index">
      <q-separator/>
      <div class="flex q-pt-md">
        <div class="flex justify-between">
          <q-avatar>
            <!-- <img v-if="imgUrl !== null" :src="imgUrl"> -->
            <i class="fas fa-user-circle fa-1x"></i>
          </q-avatar>
          <div>
            <div class="text-bold text-h6">
              {{ loadedItem.email }}
            </div>
            <div>
              {{ loadedItem.create_date }}
            </div>
            <div class="q-py-md">
              {{ loadedItem.content }}
            </div>
          </div>
          <div class="flex justify-end text-grey-7 items-start">
            <q-btn flat dense label="수정" @click="updateTempPostList"/>
            <!-- cid 붙여야함 -->
            <q-btn flat dense label="삭제" @click="deleteTempPostList"/>
          </div>
        </div>
      </div>
    </div>
  </div>
</template><script>
import axios from 'axios'


export default {
  data () {
    return {
      items: [],
      itemsNum: 0,
      loadedItems: [
        {cid : '1',
        email : '성정',
        content : '임시저장',
        create_date : '2020-05-05',
        }]
    }
  },
  methods: {
    deleteTempPostList() {
      console.log('삭제기능')
    },
    updateTempPostList() {
      console.log('수정기능')
    },
    // updateTempPostList(loadeditem.cid) {
    // axios.Post('http://~~~~~/${pid}')     
    // .then((response) => {
    // this.comments = response.data
    // })
    //   console.log('수정기능')
    // },
  },
  
  created() {
    console.log(this.loadedItems)
    // const pid = this.$route.params.id
    // axios.get('http://')
      // .then((response) => {
      //   this.loadedItems = response.data
      // }) 
      // .catch((error)=> {
      //   console.log(error)
      // })
  }
}
</script>
<style lang="">
  
</style>