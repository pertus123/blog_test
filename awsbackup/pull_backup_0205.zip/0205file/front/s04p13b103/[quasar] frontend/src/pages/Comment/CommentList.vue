<template>
  <div>
    <div v-for="comment in comments" :key="comment.cid">
      <q-separator/>
      
      <div class="flex q-pt-md justify-between">
        <div class="flex">
          <q-avatar>
            <i class="fas fa-user-circle fa-1x"></i>
          </q-avatar>
          <div>
            <div class="text-bold">
              {{ comment.email }}
            </div>
            <div class="text-grey-7 text-caption">
              {{ comment.create_date }}
            </div>
            <div class="q-py-md">
              {{ comment.content }}
            </div>
            
          </div>
        </div>
        <div v-if="comment.email == userEmail" class="text-grey-7 items-start">
          <q-btn flat dense label="수정" @click="showUpdateForm(comment.cid)"/>
          <q-btn flat dense label="삭제" @click="deleteComment(comment.cid)"/>
        </div>        

        <q-form  @submit="updateComment(comment.cid)" :id="comment.cid" style="display: none; width: 100%; margin-left: 48px">
          <q-input
            v-model="content"                
            name="comment"
            color="deep-purple-8"
            filled
            :hint="error"
            class="q-pb-sm"
          />

          <div class="row justify-end q-pb-sm">
            <q-btn 
              label="댓글 수정" 
              type="submit" 
              color="white" 
              class="text-deep-purple-8 text-caption" 
              v-close-popup dense 
              style="font-family: 'Noto Serif KR', serif;"/>
          </div>
        </q-form>
      </div>

    </div>

  </div>
</template>
<script>
import axios from 'axios'
import moment from 'moment'


export default {
  data() {
    return {
      userEmail: this.$store.state.userInfo.email,
      content: '',
      error: '',
      comments: [],
    }
  },
  methods: {
    deleteComment(cid) {
      const pid = this.$route.params.id
      axios.delete(`http://i4b103.p.ssafy.io:8080/cmt/delete?cid=${cid}&pid=${pid}`)
        .then((response) => {
          console.log(response)
        })
        .catch((error) => {
          console.log(error)
        })
    
    },
    updateComment(cid) {
      const updateForm = document.getElementById(cid)
      updateForm.style.display = 'none'
      var vm = this
      this.comments.forEach( function(comment) {
        if (comment.cid == cid) {
          const updateComment = {
            cid: cid,
            pid: comment.pid,
            content: vm.content,
            email: comment.email,
          }
          axios.put('http://i4b103.p.ssafy.io:8080/cmt/update/', updateComment)
            .then((response) => {
              console.log(response)
              vm.content = ''
              this.comments = response.data
            })
            .catch((error) => {
              console.log(error)
            })
        }
      })
    },
    showUpdateForm(cid) {
      const updateForm = document.getElementById(cid)
      if (updateForm.style.display == 'none') {
        updateForm.style.display = 'block';
      } else {
        updateForm.style.display = 'none';
      }
    }
   
  
  },
  created() {
    const pid = this.$route.params.id
    axios.get(`http://i4b103.p.ssafy.io:8080/cmt/detail/${pid}`)
      .then((response) => {
        this.comments = response.data
        for (var index in this.comments) {
          const date = moment(this.comments[index].create_date).format('LLL');
          this.comments[index].create_date = date
        } 
      })
      .catch((error) => {
        console.log(error)
      })
  },
  watch: {
    comments: function() {
      const pid = this.$route.params.id

      axios.get(`http://i4b103.p.ssafy.io:8080/cmt/detail/${pid}`)
      .then((response) => {
        this.comments = response.data
        for (var index in this.comments) {
          const date = moment(this.comments[index].create_date).format('LLL');
          this.comments[index].create_date = date
        } 
      })
      .catch((error) => {
        console.log(error)
      })

    }
  }

}
</script>
<style scoped>

  
</style>