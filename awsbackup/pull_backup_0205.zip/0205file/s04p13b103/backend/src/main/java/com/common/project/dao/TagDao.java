package com.common.project.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.common.project.model.tag.PostTag;
import com.common.project.model.tag.Tag;

public interface TagDao extends JpaRepository<Tag, Long> {
//	
//	@Query(value = "delete FROM post_tag where pid = ?1", nativeQuery = true)
	 public Optional<Tag> getTagByName(String name); //현재 DB에 태그가 있는지 체크 - tag 테이블에서
	 
	 
}