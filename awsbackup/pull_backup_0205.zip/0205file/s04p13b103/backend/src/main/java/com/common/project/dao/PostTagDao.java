package com.common.project.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.common.project.model.like.Like;
import com.common.project.model.tag.PostTag;
import com.common.project.model.tag.Tag;

public interface PostTagDao extends JpaRepository<PostTag, Long>{
	
	@Modifying
	@Transactional
	@Query(value = "delete FROM post_tag where pid = ?1", nativeQuery = true)
	 public Optional<PostTag> removePostTagByPid(Long pid);
	


}
