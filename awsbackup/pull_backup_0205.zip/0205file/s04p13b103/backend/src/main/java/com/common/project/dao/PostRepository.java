package com.common.project.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.common.project.model.like.Like;
import com.common.project.model.post.Post;

public interface PostRepository {
	Post findPostByPid(Long pid);
	Optional<Post> deletePostByPid(Long pid);
	List<Post> findByEmail(String email);
	@Query("SELECT p FROM Post p WHERE p.title like %:keyword% "
			+ "or p.content like %:keyword% ORDER BY p.pid desc")
    public List<Post> findPostByTitleOrContent(String keyword);
	

// 삭제 예정	
	//좋아요
	@Query(value = "select p.pid, p.uid from post_like p where p.pid = ?1 and p.uid =?2", nativeQuery = true)
	 Optional<Like> getLikeByPidAndUid(Long pid, Long uid);
	
	
	@Modifying
	@Transactional
	@Query(value = "insert into post_like (pid, uid) values (?1, ?2)", nativeQuery = true)
	 void insertLikeByPidAndUid(Long pid, Long uid);
	
	@Modifying
	@Transactional
	@Query(value = "delete FROM post_like where pid = ?1 and uid =?2", nativeQuery = true)
	 public Optional<Like> removeLikeByPidAndUid(Long pid, Long uid);
	
	
    
}