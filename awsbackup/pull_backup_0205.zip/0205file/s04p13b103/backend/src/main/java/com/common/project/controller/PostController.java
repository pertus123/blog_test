package com.common.project.controller;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.common.project.dao.LikeDao;
import com.common.project.dao.PostDao;
import com.common.project.dao.PostRepository;
import com.common.project.model.like.Like;
import com.common.project.model.like.LikeOutputPost;
//import com.common.project.model.member.InputMember;
import com.common.project.model.post.InputPost;
import com.common.project.model.post.Post;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;


import com.common.project.model.post.InfoInputPost;
import com.common.project.model.temppost.TempPost;


@RestController
@Transactional
@Api(tags = "PostController", description = "게시글 API")
@CrossOrigin(origins = { "*" }, maxAge = 6000)
public class PostController {
	@Autowired
	PostDao postDao;
	@Autowired
	LikeDao likeDao;

	@GetMapping("/notice/searchAllPage")
	@ApiOperation(value = "검색이나 블로그 검색 할 때 글 리스트가져오기")
	public Object searchAllPage(Long uid) {
		List<Post> postList = postDao.findAll();
		List<LikeOutputPost> likeOutputPost = new ArrayList<LikeOutputPost>();
		
		for(int i = 0; i < postList.size(); i++) {
			Optional<Like> like = likeDao.getLikeByPidAndUid(postList.get(i).getPid(), uid);
			if(like.isPresent()) { // 있으면
				likeOutputPost.add(new LikeOutputPost(postList.get(i).getPid(),postList.get(i).getTitle(),postList.get(i).getEmail(),postList.get(i).getContent(),postList.get(i).getLikes(),postList.get(i).getCreate_date(),1, postList.get(i).getPostimage()));
			}
			else { // 없으면 
				likeOutputPost.add(new LikeOutputPost(postList.get(i).getPid(),postList.get(i).getTitle(),postList.get(i).getEmail(),postList.get(i).getContent(),postList.get(i).getLikes(),postList.get(i).getCreate_date(),0, postList.get(i).getPostimage()));
			}
		}
		return new ResponseEntity<>(likeOutputPost, HttpStatus.OK);
	}

	@GetMapping("/notice/searchByKeyword")
	@ApiOperation(value = "검색이나 블로그 검색 할 때 글 리스트가져오기")
	public Object searchPageByKeyword(@RequestParam(value = "keyword") String keyword, Long uid) {

		List<Post> postList = postDao.findPostByTitleOrContent(keyword);
		List<LikeOutputPost> likeOutputPost = new ArrayList<LikeOutputPost>();
		
		for(int i = 0; i < postList.size(); i++) {
			Optional<Like> like = likeDao.getLikeByPidAndUid(postList.get(i).getPid(), uid);
			if(like.isPresent()) { // 있으면
				likeOutputPost.add(new LikeOutputPost(postList.get(i).getPid(),postList.get(i).getTitle(),postList.get(i).getEmail(),postList.get(i).getContent(),postList.get(i).getLikes(),postList.get(i).getCreate_date(),1));
			}
			else { // 없으면 
				likeOutputPost.add(new LikeOutputPost(postList.get(i).getPid(),postList.get(i).getTitle(),postList.get(i).getEmail(),postList.get(i).getContent(),postList.get(i).getLikes(),postList.get(i).getCreate_date(),0));
			}
		}
		
		return new ResponseEntity<>(likeOutputPost, HttpStatus.OK);

	}

	@GetMapping("/notice/listUserPage")
	@ApiOperation(value = "사용자 페이지 리스트")
	public Object listUserPage(@RequestParam String email) {
		List<Post> postList = postDao.findByEmail(email);
		return new ResponseEntity<>(postList, HttpStatus.OK);
	}

	@GetMapping("/notice/detailPage/{pid}")
	@ApiOperation(value = "상세페이지")
	public Object detailPage(@PathVariable Long pid) {
		Post onePost = postDao.findPostByPid(pid);
		return new ResponseEntity<>(onePost, HttpStatus.OK);
	}

	@PostMapping("/notice/writePage")
	@ApiOperation(value = "글쓰기", httpMethod = "POST", produces = "multipart/form-data")
	public Object writePage(InfoInputPost infoinputPost) {

		System.out.println("1");
		Post post = new Post(infoinputPost.getTitle(), infoinputPost.getEmail(),
				infoinputPost.getContent(),	infoinputPost.getLikes());
		System.out.println("2");
		String saveName = null;
		System.out.println("3");

		String UPLOAD_PATH = "/var/www/html/dist/spa/thumbimg"; // 서버
		System.out.println("4");
		UUID uuid = UUID.randomUUID();
		System.out.println("5");
		saveName = uuid + "_" + infoinputPost.getPostimage().getOriginalFilename();
		System.out.println("6");
		File saveFile = new File(UPLOAD_PATH, saveName);
		System.out.println("7");
		try {
		System.out.println("8");
			infoinputPost.getPostimage().transferTo(saveFile);
		System.out.println("9");
			saveName = "http://i4b103.p.ssafy.io/thumbimg/" + saveName;
		System.out.println("10");
			post.setPostimage(saveName);
		System.out.println("11");
		} catch (IOException e) {
			e.printStackTrace();
		}
		post.setPostimage(saveName);
		System.out.println("12");
		postDao.save(post);
		System.out.println("13");

		return new ResponseEntity<>(post, HttpStatus.OK);
	}
	
	
	
	@PostMapping("/notice/uploadImg")
	@ApiOperation(value = "파일첨부", httpMethod = "POST", produces = "multipart/form-data")
	public Object uploadimg(MultipartFile img) {

		String saveName = null;
		String UPLOAD_PATH = "/var/www/html/dist/spa/postimg"; // 서버
		UUID uuid = UUID.randomUUID();
		
		System.out.println("1");
		System.out.println(img.getOriginalFilename());
		saveName = uuid + "_" + img.getOriginalFilename();
		File saveFile = new File(UPLOAD_PATH, saveName);
		try {
			saveName = "http://i4b103.p.ssafy.io/postimg/" + saveName;
			img.transferTo(saveFile);//저장완료
		} catch (IOException e) {
			e.printStackTrace();
		}
		return new ResponseEntity<>(saveName, HttpStatus.OK);
	}

	
	@DeleteMapping("/notice/deletePage/{pid}")
	@ApiOperation(value = "글삭제")
	public Object deletePage(@PathVariable Long pid) {
		Optional<Post> postOpt = postDao.deletePostByPid(pid);
		if (postOpt.isPresent()) {
			return new ResponseEntity<>("success", HttpStatus.OK);
		} else
			return new ResponseEntity<>("fail", HttpStatus.NOT_FOUND);
	}

	@PutMapping("/notice/updatePage")
	@ApiOperation(value = "글 수정")
	public Object updatePage(@RequestBody InputPost inputPost) {
		Post post = new Post(inputPost.getPid(), inputPost.getTitle(), inputPost.getEmail(), inputPost.getContent(),
				inputPost.getLikes());
		postDao.save(post);
		return new ResponseEntity<>("success", HttpStatus.OK);
	}

	@Transactional
	@GetMapping("/notice/likeSwitch")
	@ApiOperation(value = "좋아요1&안좋아요0 누를 때 반응")
	public Object likePage(Long pid, Long uid) {
		Optional<Like> like = likeDao.getLikeByPidAndUid(pid,uid);
		Post onePost = postDao.findPostByPid(pid);
		if(like.isPresent()) { // 값이 존재하면, 좋아요 -> 안좋아요
			likeDao.removeLikeByPidAndUid(pid,uid);
			onePost.setLikes(onePost.getLikes() -1);
			postDao.save(onePost);
		}
		else{  // 값이 없어 -> 안좋아요 -> 좋아요
			likeDao.insertLikeByPidAndUid(pid,uid);
			onePost.setLikes(onePost.getLikes() + 1);
			postDao.save(onePost);
		}
		return new ResponseEntity<>("success", HttpStatus.OK);
	}
}
