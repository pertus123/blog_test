package com.common.project.dao;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.Query;

import com.common.project.model.comment.Comment;

public interface CommentRepository {

}
