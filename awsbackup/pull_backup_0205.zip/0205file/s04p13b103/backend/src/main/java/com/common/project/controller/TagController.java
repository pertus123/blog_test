package com.common.project.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.CrossOrigin;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.common.project.dao.PostTagDao;
import com.common.project.dao.TagDao;
import com.common.project.model.tag.PostTag;
import com.common.project.model.tag.Tag;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@Transactional
@Api(tags = "TagController", description = "임시글 API")
@CrossOrigin(origins = { "*" }, maxAge = 6000)
public class TagController {
	
//	@Autowired
//	private TagDao tagDao;
//	@Autowired
//	private PostTagDao postTagDao;
//	
//	@PostMapping("/label/write")
//	@ApiOperation(value = "태그 입력")
//	public Object write(Long pid, String tags[]) {
//		// 일단 기존 post_tag 에 있는 태그들 다 삭제 pid 기준
//		
//		postTagDao.removePostTagByPid(pid);
//		
//		for(int i  = 0; i < tags.length; i++) {
//			// 1 현재 DB에 태그가 있는지 체크 - tag 테이블에서
//			Optional<Tag> isTag = tagDao.getTagByName(tags[i]);
//			if(!isTag.isPresent()) {	// 2.1 없으면 새로운 태그와 이름을 만듬.
//				Tag tag = new Tag();
//				tag.setName(tags[i]);
//				tagDao.save(tag);
//			}
//			
//			// 3. 이제 있을 때 있어질 때, 그 태그 id와 pid의 정보를 post_tag에 저장.
//			PostTag postTag = new PostTag();
//			postTag.setPid(pid);
//			postTag.setTid(tid); // 이 부분 수정
//			postTagDao.save(postTag);
//			
//		}
//		
//		
//		
//		
//		
//		return null;
//	}
//	
//	//만들어야할 sql, post_tag와 tag 조합해서 정보 가져오기
//	// 태그 삭제
//	// 해당 태그가 있는지 체크
//	//태그 생성
//	
//	@GetMapping("/label/detail")
//	@ApiOperation(value = "태그 가져오기")
//	public Object detail(Long pid) {
//		Tag tag = postTagDao // join
//				
//		return new ResponseEntity(tag, HttpStatus.OK);
//	}

}
