package com.common.project.model.temppost;


import org.springframework.web.multipart.MultipartFile;

public class TInfoInputPost {
	private Long tid;
	private String title;
	private String email;
	private String content;
	private int likes;
	private MultipartFile tpostimage;

	public TInfoInputPost() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TInfoInputPost(Long tid, String title, String email, String content, int likes, MultipartFile tpostimage) {
		this.tid = tid;
		this.title = title;
		this.email = email;
		this.content = content;
		this.likes = likes;
		this.tpostimage = tpostimage;
	}

	public Long getPid() {
		return tid;
	}

	public void setPid(Long pid) {
		this.tid = pid;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public int getLikes() {
		return likes;
	}

	public void setLikes(int likes) {
		this.likes = likes;
	}

	public MultipartFile getTPostimage() {
		return tpostimage;
	}

	public void setTPostimage(MultipartFile tpostimage) {
		this.tpostimage = tpostimage;
	}
}