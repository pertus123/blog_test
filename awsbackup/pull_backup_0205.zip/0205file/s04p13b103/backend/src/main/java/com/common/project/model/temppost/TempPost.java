package com.common.project.model.temppost;


import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "temppost")
public class TempPost {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long tid;
	private String title;
	private String email;
	private String content;
	private int likes;
	private String tpostimage;
	@Column(insertable = false, updatable = false)
	private LocalDateTime create_date;

	public TempPost() {
		super();
	}

	public TempPost(String title, String email, String content, int likes) {
		this.title = title;
		this.email = email;
		this.content = content;
		this.likes = likes;
	}

	public TempPost(Long tid, String title, String email, String content, int likes) {
		this.tid = tid;
		this.title = title;
		this.email = email;
		this.content = content;
		this.likes = likes;
	}
	
	public TempPost(Long tid, String title, String email, String content, int likes, String tpostimage) {
		this.tid = tid;
		this.title = title;
		this.email = email;
		this.content = content;
		this.likes = likes;
		this.tpostimage = tpostimage;
	}

	public Long getTid() {
		return tid;
	}

	public void setTid(Long tid) {
		this.tid = tid;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public int getLikes() {
		return likes;
	}

	public void setLikes(int likes) {
		this.likes = likes;
	}
	
	public String getTPostimage() {
		return tpostimage;
	}
	
	public void setTPostimage(String tpostimage) {
		this.tpostimage = tpostimage;
	}

	public LocalDateTime getCreate_date() {
		return create_date;
	}
	
	public void setCreate_date(LocalDateTime create_date) {
		this.create_date = create_date;
	}
}