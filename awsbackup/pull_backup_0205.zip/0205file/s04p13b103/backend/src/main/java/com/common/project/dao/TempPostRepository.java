package com.common.project.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.common.project.model.temppost.TempPost;

public interface TempPostRepository{
	List<TempPost> findByEmail(String email);
	Optional<TempPost> deletePostByTid(Long tid);
//	TempPost findPostByUid(Long uid);
//	Optional<TempPost> deleteByTid(Long Tid);
//	@Query("SELECT p FROM Post p WHERE p.title like %:keyword% "
//			+ "or p.content like %:keyword% ORDER BY p.pid desc")
//    public List<TempPost> findPostByTitleOrContent(String keyword);
}
