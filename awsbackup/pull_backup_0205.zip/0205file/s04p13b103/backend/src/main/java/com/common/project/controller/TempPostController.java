package com.common.project.controller;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.common.project.dao.PostDao;
import com.common.project.dao.TempPostDao;
import com.common.project.model.member.SignupInputMember;
import com.common.project.model.post.Post;
import com.common.project.model.temppost.TInfoInputPost;
import com.common.project.model.temppost.TempPost;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@Transactional
@Api(tags = "TempPostController", description = "임시글 API")
@CrossOrigin(origins = { "*" }, maxAge = 6000)
public class TempPostController {

	@Autowired
	PostDao postDao;
	@Autowired
	TempPostDao tempPostDao;
	
	@PostMapping("/temp/notice/write")
	@ApiOperation(value = "임시 저장하기", httpMethod = "POST", produces = "multipart/form-data")
	public Object writeTemp(TInfoInputPost tinfoinputPost) {
		TempPost temppost = new TempPost(tinfoinputPost.getTitle(), tinfoinputPost.getEmail(),
				tinfoinputPost.getContent(),	tinfoinputPost.getLikes());
		String saveName = null;

		String UPLOAD_PATH = "C:\\source\\s04p12b103-develop\\s04p12b103-develop"
				+ "\\backend\\src\\main\\resources\\images"; // 서버
		UUID uuid = UUID.randomUUID();
		saveName = uuid + "_" + tinfoinputPost.getTPostimage().getOriginalFilename();
		File saveFile = new File(UPLOAD_PATH, saveName);
		try {
			tinfoinputPost.getTPostimage().transferTo(saveFile);
			saveName = "http://i4b103.p.ssafy.io/postimg/" + saveName;
			temppost.setTPostimage(saveName);
		} catch (IOException e) {
			e.printStackTrace();
		}
		temppost.setTPostimage(saveName);
		tempPostDao.save(temppost);

		return new ResponseEntity<>(temppost, HttpStatus.OK);
	}
	
	@PostMapping("/temp/notice/detail")
	@ApiOperation(value = "임시저장 상세페이지 불러오기")
	public Object detailTemp(@RequestParam String email) {
		/////////// 임시저장된 모든 글 불러와야하나 tid로 불러와야하나
		List<TempPost> tempList = tempPostDao.findByEmail(email);

		return new ResponseEntity<>(tempList, HttpStatus.OK);
	}
	
	@PostMapping("/temp/notice/save")
	@ApiOperation(value = "게시글로 저장")
	public Object saveTemp(TInfoInputPost tinfoinputPost) {
		Post post = new Post(tinfoinputPost.getTitle(), tinfoinputPost.getEmail(),
				tinfoinputPost.getContent(),tinfoinputPost.getLikes());
		postDao.save(post);
		return new ResponseEntity<>("success", HttpStatus.OK);
	}
	
	@DeleteMapping("/temp/notice/delete/{tid}")
	@ApiOperation(value = "임시 글삭제")
	public Object deletePage(@PathVariable Long tid) {
		Optional<TempPost> tpostOpt = tempPostDao.deletePostByTid(tid);
		// System.out.println(postOpt.toString());
		if (tpostOpt.isPresent()) {
			return new ResponseEntity<>("success", HttpStatus.OK);
		} else
			return new ResponseEntity<>("fail", HttpStatus.NOT_FOUND);

	}
}
