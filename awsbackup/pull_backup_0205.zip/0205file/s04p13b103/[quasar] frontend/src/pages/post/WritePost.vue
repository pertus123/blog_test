<template>
  <div class="row justify-center">
    <div class="col-10">
      <div class="q-pa-md q-gutter-sm">
        <q-input class="q-pb-md title" v-model="title" placeholder="글 제목" color="deep-purple-8"/>

        <v-md-editor 
          left-toolbar="undo redo clear | h bold italic strikethrough quote | ul ol table hr | link image code " 
          v-model="content" 
          height="400px"
          :disabled-menus="[]"
          @upload-image="handleUploadImage">
        </v-md-editor>

        <div class="row justify-end q-py-md">
          <!-- <q-btn label="글쓰기" type="submit" color="deep-purple-8" @click="uploadPost" style="font-family: 'Noto Serif KR', serif;"/> -->
          <q-btn label="글쓰기" color="deep-purple-8" @click="thumImgModal = true" style="font-family: 'Noto Serif KR', serif;"/>
          <q-btn label="임시저장" type="submit" color="white"  text-color="deep-purple-8" class="q-ml-sm" @click="savePost" style="font-family: 'Noto Serif KR', serif;"/>
        
          <q-dialog
            v-model="thumImgModal"
          >
            <q-card style="width: 700px; max-width: 80vw;">
              <q-card-section>
                <div class="text-h6">포스트 썸네일 올리기</div>
              </q-card-section>

              <q-card-section class="q-pt-none">
                <img v-if="imgUrl !==''" :src="imgUrl" alt="">
                <q-file style="max-width: 300px" filled bottom-slots v-model="thumImg" label="Label" counter>
                  <template v-slot:prepend>
                    <q-icon name="cloud_upload" @click.stop />
                  </template>
                  <template v-slot:append>
                    <q-icon name="close" @click.stop="model = null" class="cursor-pointer" />
                  </template>

                  <template v-slot:hint>
                    Field hint
                  </template>
                </q-file>

              </q-card-section>

              <q-card-actions align="right" class="bg-white text-teal">
                <q-btn flat label="올리기" v-close-popup />
              </q-card-actions>
            </q-card>
          </q-dialog>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import Vue from 'vue';
import VMdEditor from '@kangc/v-md-editor';
import '@kangc/v-md-editor/lib/style/base-editor.css';
import githubTheme from '@kangc/v-md-editor/lib/theme/github.js';
import '@kangc/v-md-editor/lib/theme/style/github.css';
import enUS from '@kangc/v-md-editor/lib/lang/en-US';
import axios from 'axios';

VMdEditor.use(githubTheme);

VMdEditor.lang.use('en-US', enUS);

Vue.use(VMdEditor);

export default {
  data () {
    return {
      title: '',
      content: '# 임시 에디터 \n### 임시 에디터',
      thumImgModal: false,
      thumImg: '',
      imgUrl: '',
    }
  },
  methods: {
    uploadPost() {
      const post = {
        email: this.$store.state.userInfo.email,
        title: this.title,
        content: this.content
      }
      console.log(post)
      axios.post('http://i4b103.p.ssafy.io:8080/notice/writePage', post)
        .then((response) => {
          console.log(response)
          this.$router.push('/')
        })
        .catch((error) => {
          console.log(error)
        })
    },
    savePost() {
      // 글 임시저장하기
    },
    handleUploadImage(event, insertImage, files) {
      // Get the files and upload them to the file server, then insert the corresponding content into the editor
      console.log(files);

      // Here is just an example
      insertImage({
        url:
          'https://ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=1269952892,3525182336&fm=26&gp=0.jpg',
        desc: 'desc',
        // width: 'auto',
        // height: 'auto',
      });
    },
  },
   watch: {
    thumImg: function (v) {
      if (this.thumImg) {
        this.imgUrl = URL.createObjectURL(this.thumImg)
      }
    },
  },
}
</script>
<style scoped>
.title {
  font-size: 25px;
  font-weight: bold;
}
  
</style>

