<template>
  <div class="row justify-center">
    <div class="col-10">
      <div class="q-pa-md q-gutter-sm">
        <q-input class="q-pb-md title" v-model="title" placeholder="글 제목" color="deep-purple-8"/>

        <v-md-editor left-toolbar="undo redo clear | h bold italic strikethrough quote | ul ol table hr | link image code " v-model="content" height="400px"></v-md-editor>

        <div class="row justify-end q-py-md">
          <q-btn label="수정하기" type="submit" color="deep-purple-8" @click="updatePost" style="font-family: 'Noto Serif KR', serif;"/>
          <q-btn label="임시저장" type="submit" color="white"  text-color="deep-purple-8" class="q-ml-sm" @click="savePost" style="font-family: 'Noto Serif KR', serif;"/>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import Vue from 'vue';
import VMdEditor from '@kangc/v-md-editor';
import '@kangc/v-md-editor/lib/style/base-editor.css';
import githubTheme from '@kangc/v-md-editor/lib/theme/github.js';
import '@kangc/v-md-editor/lib/theme/style/github.css';
import enUS from '@kangc/v-md-editor/lib/lang/en-US';
import axios from 'axios';

VMdEditor.use(githubTheme);

VMdEditor.lang.use('en-US', enUS);

Vue.use(VMdEditor);

export default {
  data () {
    return {
      pid: '',
      email: '',
      title: '',
      content: ''
    }
  },
  methods: {
    updatePost() {
      const post = {
        pid: this.pid,
        email: this.$store.state.userInfo.email,
        title: this.title,
        content: this.content
      }
      console.log(post)
      axios.put('http://i4b103.p.ssafy.io:8080/notice/updatePage', post)
        .then((response) => {
          console.log(response)
          this.$router.push('/')
        })
        .catch((error) => {
          console.log(error)
        })
    },
    savePost() {
      // 글 임시저장하기
    }
  },
  created() {
    const id = this.$route.params.id;
    axios.get(`http://i4b103.p.ssafy.io:8080/notice/detailPage/${id}`)
      .then((response) => {
        this.pid = response.data.pid
        this.title = response.data.title
        this.content = response.data.content
        this.email = response.data.email
      })
      .catch((error) => {
        console.log(error)
      })
    
  }
}
</script>
<style scoped>
.title {
  font-size: 25px;
  font-weight: bold;
}
  
</style>