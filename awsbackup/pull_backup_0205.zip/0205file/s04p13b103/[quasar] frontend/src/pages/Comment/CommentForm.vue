<template>
  <div class="q-pt-md q-pb-xl">
    <q-form @submit="submitComment" class="q-gutter-md">
      <q-input
        name="comment"
        v-model="content"
        color="deep-purple-8"
        placeholder="댓글을 작성하세요."
        filled
        :hint="error"
        clearable
      />

      <div class="row justify-end q-mt-none">
        <q-btn label="댓글 작성" type="submit" color="deep-purple-8" style="font-family: 'Noto Serif KR', serif;"/>
      </div>
    </q-form>

  </div>
</template>
<script>
import axios from 'axios'
export default {
  data () {
    return {
      content: '',
      error: '',
    }
  },
  methods: {
    submitComment() {
      if (this.content.length > 4) {
        const commentForm = {
          content: this.content,
          email: this.$store.state.userInfo.email,
          pid: this.$route.params.id
        }
        axios.post('http://i4b103.p.ssafy.io:8080/cmt/write', commentForm)
          .then((response) => {
            console.log(response)
            this.content = ''
            this.error = ''
          })
          .catch((error) => {
            console.log(error)
          })
      } else {
        this.error = '댓글은 다섯 글자 이상 작성해주세요.'
      }
    }
  },
 
}
</script>
<style>

</style>