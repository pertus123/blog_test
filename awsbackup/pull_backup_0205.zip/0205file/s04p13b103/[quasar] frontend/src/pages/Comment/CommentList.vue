<template>
  <div >
    <div v-for="comment in comments" :key="comment.cid">
      <q-separator/>
      
      <div class="flex q-pt-md">
        <div class="flex justify-between">
          <q-avatar>
            <!-- <img v-if="imgUrl !== null" :src="imgUrl"> -->
            <i class="fas fa-user-circle fa-1x"></i>
          </q-avatar>
          <div>
            <div class="text-bold text-h6">
              {{ comment.email }}
            </div>
            <div>
              {{ comment.create_date }}
            </div>
            <div class="q-py-md">
              {{ comment.content }}
            </div>
          </div>
          <div class="flex justify-end text-grey-7 items-start">
            <q-btn flat dense label="수정" />
            <q-btn flat dense label="삭제" @click="deleteComment(comment.cid)"/>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import axios from 'axios'
import moment from 'moment'


export default {
  data() {
    return {
      comments: [],
    }
  },
  methods: {
    deleteComment(cid) {
      axios.delete(`http://i4b103.p.ssafy.io:8080/cmt/delete/${cid}`)
        .then((response) => {
          console.log(response)

          const pid = this.$route.params.id
          axios.get(`http://i4b103.p.ssafy.io:8080/cmt/detail/${pid}`)
            .then((response) => {
              this.comments = response.data

              for (var index in this.comments) {
                const date = moment(this.comments[index].create_date).format('LLL');
                this.comments[index].create_date = date
              } 

            })
            .catch((error) => {
              console.log(error)
            })
              })
        .catch((error) => {
          console.log(error)
        })
    },
  
  },
  created() {
    const pid = this.$route.params.id
    axios.get(`http://i4b103.p.ssafy.io:8080/cmt/detail/${pid}`)
      .then((response) => {
        this.comments = response.data

        for (var index in this.comments) {
          const date = moment(this.comments[index].create_date).format('LLL');
          this.comments[index].create_date = date
        } 

      })
      .catch((error) => {
        console.log(error)
      })
  },
}
</script>
<style lang="">
  
</style>