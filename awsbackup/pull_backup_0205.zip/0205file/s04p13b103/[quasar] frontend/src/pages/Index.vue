<template>
  <div>
    <post-list></post-list>
  </div>
</template>
<script>
import PostList from '../pages/post/PostList'
export default {
  components: {
    PostList
  }
}
</script>
<style lang="">
  
</style>