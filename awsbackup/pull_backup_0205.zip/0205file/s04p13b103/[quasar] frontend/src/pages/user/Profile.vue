<template>
  <div class="q-pa-md row justify-center">
    <div class="col-10 col-md-6">
      <div class="q-pa-md">

        <div class="flex justify-start items-center q-pb-lg">
          <q-avatar size="80px">
              <img v-if="profileimage" :src="profileimage">
              <i v-else class="fas fa-user-circle fa-2x"></i>
            </q-avatar>
          <div>
            <div class="q-pl-sm text-h6">{{ name }}</div>
            <div class="q-pl-sm">{{ introduce }}</div>
          </div>
        </div>
                    
        <div class="q-gutter-y-md" >
          <q-card>
            <q-tabs
              v-model="tab"
              dense
              class="text-grey-9"
              active-color="deep-purple-8"
              indicator-color="deep-purple-8"
              align="justify"
              narrow-indicator
            >
              <q-tab name="글" label="글" />
              <q-tab name="스킬트리" label="스킬트리" />
              <q-tab name="강의목록" label="강의목록" />
              <q-tab name="소개" label="소개" />
            </q-tabs>

            <q-separator />

            <q-tab-panels v-model="tab" animated>
              <q-tab-panel name="글">
                <div class="text-h6">글</div>
                Lorem ipsum dolor sit amet consectetur adipisicing elit.
              </q-tab-panel>

              <q-tab-panel name="스킬트리">
                <div class="text-h6">스킬트리</div>
                Lorem ipsum dolor sit amet consectetur adipisicing elit.
              </q-tab-panel>

              <q-tab-panel name="강의목록">
                <div class="text-h6">강의목록</div>
                Lorem ipsum dolor sit amet consectetur adipisicing elit.
              </q-tab-panel>
              <q-tab-panel name="소개">
                <div class="text-h6">소개</div>
                Lorem ipsum dolor sit amet consectetur adipisicing elit.
              </q-tab-panel>
            </q-tab-panels>
          </q-card>

        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data () {
    return {
      tab: '글',
      name: '익명1234',
      introduce: this.$store.state.userInfo.introduce,
      profileimage: this.$store.state.userInfo.profileimage,
    }
  }
}
</script>
<style lang="">
  
</style>