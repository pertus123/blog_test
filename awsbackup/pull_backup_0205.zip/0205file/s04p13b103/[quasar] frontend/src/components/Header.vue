<template>
  <div class="q-pa-md header">
    <q-toolbar class="bg-deep-purple-8 text-white shadow-2 rounded-borders" >
      
      <q-btn stretch flat label="쉬운 개발자 블로그" class="text-h6" to="/"/>

      <q-space />
      <q-input dark dense standout v-model="search" input-class="text-right" class="q-ml-md gt-sm" @keypress.enter="searchPost">
        <template v-slot:append >
            <q-btn flat round dense icon="search" class="q-mr-xs" @click="searchPost"/>
        </template>
      </q-input>
     
        <!-- 화면이 sm보다 큰 경우 -->
      <q-tabs v-model="tab" shrink >
        <div class="gt-sm flex">
       
        <div v-if="this.$store.state.isLogin == true" class="flex">
          <router-link class="tabs" to="/writepost"><q-tab name="글쓰기" label="글쓰기" /></router-link>
          <q-btn flat class="items-center">
            <!-- 프사 불러오기 가능해지면 이미지 넣을 예정 -->
            <q-avatar size="md">
              <!-- <img v-if="profileimage !== null" :src="profileimage"> -->
              <!-- <i v-else class="fas fa-user-circle fa-2x"></i> -->
              <i class="fas fa-user-circle fa-2x"></i>
            </q-avatar>
            <div class="q-pa-sm">▾</div>
            <q-menu>
              <q-list style="min-width: 120px">
                <q-item clickable v-close-popup>
                  <q-item-section>
                    <router-link style="text-decoration: none; color:black;" to="/userinfo">회원정보 수정</router-link>
                  </q-item-section>
                </q-item>
                <q-item clickable v-close-popup>
                  <q-item-section>
                    <router-link style="text-decoration: none; color:black;" to="#">임시 글</router-link>
                  </q-item-section>
                </q-item>
                <q-item clickable v-close-popup>
                  <q-item-section @click="logout">로그아웃</q-item-section>
                </q-item>
              </q-list>
            </q-menu>
          </q-btn>
        </div>

        <div v-else class="flex">
          <router-link class="tabs" to="/login"><q-tab name="로그인" label="로그인" /></router-link>
          <router-link class="tabs" to="/signup"><q-tab name="회원가입" label="회원가입" /></router-link>
        </div>
        </div>

        <div class="lt-md flex">
          <div v-if="this.$store.state.isLogin == true">
            <q-btn flat round dense icon="menu" />
            <q-menu>
              <q-list style="min-width: 120px">
                <q-item clickable v-close-popup>
                  <q-item-section>
                    <router-link class="tabs" to="/writepost" style="text-decoration: none; color:black;" >글쓰기</router-link>
                  </q-item-section>
                </q-item>
                <q-item clickable v-close-popup>
                  <q-item-section>
                    <router-link style="text-decoration: none; color:black;" to="/userinfo">회원정보 수정</router-link>
                  </q-item-section>
                </q-item>
                <q-item clickable v-close-popup>
                  <q-item-section>
                    <router-link style="text-decoration: none; color:black;" to="#">임시 글</router-link>
                  </q-item-section>
                </q-item>
                <q-item clickable v-close-popup>
                  <q-item-section @click="logout">로그아웃</q-item-section>
                </q-item>
              </q-list>
            </q-menu>
          </div>
          <div v-else class="flex">
            <router-link class="tabs" to="/login"><q-tab name="로그인" label="로그인" /></router-link>
            <router-link class="tabs" to="/signup"><q-tab name="회원가입" label="회원가입" /></router-link>
          </div>

        </div>
        
      </q-tabs>
    </q-toolbar>
  </div>
</template>
<script>

export default {
  data () {
    return {
      location: window.location,
      tab: '',
      search: '',
      profileimage: null,
    }
  },
  methods: {
    logout() {
      localStorage.removeItem('auth-token')
      this.$store.dispatch('logout')
      this.$router.push('/')
    },
    searchPost() {
      this.$router.push(`/searchedpost/${this.search}`).catch(error => {
        if(error.name === "NavigationDuplicated") {
          location.reload();
        }
      });
      this.search = ""
      
    }
  },
  created() {
    if (this.$store.state.userInfo.profileimage !== 'http://i4b103.p.ssafy.io/profileimg/null') {
      this.profileimage = this.$store.state.userInfo.profileimage
    }
  }
}
</script>

<style scoped>
.header {
  font-family: 'Noto Serif KR', serif;
  padding-bottom: 40px;
}
.tabs {
  color: white;
  text-decoration: none;
}
</style>